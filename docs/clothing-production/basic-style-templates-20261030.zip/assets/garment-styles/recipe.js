(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.GarmentStyleRecipe=api;})(typeof window==='undefined'?globalThis:window,function(){
 'use strict';
 const patterns=['solid','stripes','plaid','floral','gothic-print'],names={solid:'纯色',stripes:'条纹',plaid:'格纹',floral:'花卉印花','gothic-print':'哥特印花'};
 function create(style,input={}){
  if(!style?.styleId||!style.source?.sha256)throw Error('缺少款式与源图版本');
  const allowed=['pattern','fabric','baseColor','inkColor','scale','direction','motif','placement'];for(const key of Object.keys(input))if(!allowed.includes(key))throw Error('款式结构不能由贴图配方修改：'+key);
  const pattern=input.pattern||'solid';if(!patterns.includes(pattern))throw Error('未知纹样');
  const palette={base:input.baseColor||'#eae4d8',ink:input.inkColor||'#29242b'};for(const v of Object.values(palette))if(!/^#[0-9a-f]{6}$/i.test(v))throw Error('颜色无效');
  const scale=Number(input.scale??24);if(!Number.isFinite(scale)||scale<4||scale>160)throw Error('纹样间距应为 4–160 人物画布像素');
  const placement=input.placement||'front-body';if(!['front-body','all-fabric','chest'].includes(placement))throw Error('印花位置无效');
  const direction=input.direction||'horizontal';if(!['horizontal','vertical','diagonal'].includes(direction))throw Error('纹样方向无效');
  const recipe={version:1,styleId:style.styleId,baseId:style.id,sourceSha256:style.source.sha256,fitSha256:style.source.fitSha256,geometry:style.assets.geometry,
   appearance:{fabric:String(input.fabric||'棉质').slice(0,120),pattern,palette,scale,direction,motif:String(input.motif||'').slice(0,1000),placement},
   output:{newVariant:true,overwriteOriginal:false,canvas:[939,1676],backTransparent:true,applyFitAgain:false},
   readiness:{structureReady:true,cleanSurfaceReady:style.status.cleanSurface==='approved',publishable:false,needs:['制作或核验无旧纹样的干净材质底稿','绘制结构与材质分层','按指定位置生成并映射纹样','全身与 100% 局部验收','实际衣橱试穿、卸装、刷新验收']}};
  recipe.prompt=`制作一件固定姿势二维换装服装，款式：${style.name}。版型：${style.fit}；领口：${style.neckline}；袖型：${style.sleeve}；衣长/下摆：${style.hem}；正面结构：${style.construction}。严格锁定 coverage/silhouette 的当前已归位服装轮廓，源彩图仅核对结构，不继承原颜色、文字、纹样、面料。新面料：${recipe.appearance.fabric}；新表面设计：${names[pattern]}，底色 ${palette.base}，纹样色 ${palette.ink}，纹样间距 ${scale} 画布像素，方向 ${direction}，位置 ${placement}。${recipe.appearance.motif?'图案要求：'+recipe.appearance.motif+'。':''}先绘制无旧纹样干净底稿，保留前领、门襟、口袋、接缝、褶皱与袖口前缘结构，再加新表面设计；图案随衣片方向、褶皱和遮挡变化。只画正面可见衣料，无身体、无皮肤、无内片、无后领圈、无袖口内筒、无开襟背部连接片；back 全透明。939×1676 当前穿戴坐标，不再次拟合，不扩大衣服 alpha，不用人物 alpha 扩边。保留原件、网格、曲线、印花与备注，作为新派生候选交付。`;
  return recipe;
 }
 return {create,patterns,names};
});
